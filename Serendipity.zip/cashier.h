#ifndef CASHIER_H
#define CASHIER_H

#include "bookType.h"

int cashier(bookType array[], int bookCount);

#endif
